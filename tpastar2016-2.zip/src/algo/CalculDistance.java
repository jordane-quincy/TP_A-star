package algo;

import environment.Cell;

public interface CalculDistance {
	double compute(Cell a, Cell b);

}
